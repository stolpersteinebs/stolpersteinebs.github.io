---
layout: default
title: "Lernen und Werte"
permalink: /lernenundwerte/
---
[Zurück zur Startseite](https://stolpersteinebs.github.io)
# Lernen und Werte
>von **Talah, Isabelle, Mailin, Ella, Adiya, Sophie, Aleksandra, Victoria, Marlitt, Leni, Elli**
