---
layout: default
title: Inspiration & Lehre
permalink: /inspiration/
---

# Inspiration & Lehre

Hier findest du interaktive Spiele passend zur Ausstellung:

- [Koscher Sammelspiel](/koscherspiel/)
- [Feiertags-Quiz](/feiertagsquiz/)
- [3D Lernwelt Judentum](/dreidspiel/)

Viel Spaß beim Lernen und Entdecken.
